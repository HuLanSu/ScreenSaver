//
//  jikescreensaverView.h
//  jikescreensaver
//
//  Created by sugc on 2022/6/29.
//

#import <ScreenSaver/ScreenSaver.h>

@interface jikescreensaverView : ScreenSaverView

@end
